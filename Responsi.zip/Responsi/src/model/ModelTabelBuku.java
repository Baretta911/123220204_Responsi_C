/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author PC PRAKTIKUM
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;
public class ModelTabelBuku extends AbstractTableModel{
    List<databuku>db;
    String kolom[]={"ID","NAMA PENYEWA","JUDUL","JENIS","NOMOR TELEPON","DURASi","TOTAL"};
    public ModelTabelBuku(List<databuku> db){
    this.db= db;
}

    
    @Override
    public int getRowCount() {
        return db.size();
    }

    @Override
    public int getColumnCount() {
        return kolom.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return db.get(rowIndex).getId();
            case 1:
                return db.get(rowIndex).getNama_penyewa();
            case 2:
                return db.get(rowIndex).getJudul_buku();
            case 3:
                return db.get(rowIndex).getJenis_buku();
            case 4:
                return db.get(rowIndex).getNomor_telepon(); 
            case 5:
                return db.get(rowIndex).getDurasi_sewa(); 
            case 6:
                return db.get(rowIndex).getTotal_biaya();
            default :
                return null;
        }
    }

}
