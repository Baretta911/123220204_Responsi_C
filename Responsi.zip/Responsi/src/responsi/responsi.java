/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsi;

/**
 *
 * @author PC PRAKTIKUM
 */
public class responsi {
     public static void main(String[] args) {
         MainView v = new MainView();
         v.setVisible(true);
         v.setLocationRelativeTo(null);
// TODO code application logic here
    }
}
