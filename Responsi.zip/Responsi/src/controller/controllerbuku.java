/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author PC PRAKTIKUM
 */
import DAO.*;
import DAOimplement.DAOimplementbuku;
import model.*;
import connect.connection;
import java.util.List;
import responsi.MainView;
public class controllerbuku {
    MainView frame;
    DAOimplementbuku impbuku;
    List<databuku> db;
    public controllerbuku(MainView frame){
        this.frame = frame;
        impbuku = new DAObuku();
        db = impbuku.getALL();
    }
    public void isitabel(){
    db = impbuku.getALL();
    ModelTabelBuku mb =new ModelTabelBuku(db);
    frame.getTabelbuku().setModel(mb);
    }
    
}
