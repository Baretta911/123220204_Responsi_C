/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author PC PRAKTIKUM
 */
import DAOimplement.DAOimplementbuku;
import connect.connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.databuku;

public class DAObuku implements DAOimplementbuku{

    @Override
    public void insert(databuku buku) {
        try{
        String query = "INSERT INTO sewa_buku(id,nama_penyewa,judul_buku,jenis_buku,nomor_telepon,durasi_sewa,Total_biaya) VALUES (?,?,?,?,?,?,?);";
            databuku dm = new databuku();
            PreparedStatement st ;
            st = connection.connenct().prepareStatement(query);
            st.setInt(1,buku.getId());
            st.setString(2,buku.getNama_penyewa());
            st.setString(3,buku.getJudul_buku());
            st.setString(4,buku.getJenis_buku());
            st.setString(5,buku.getNomor_telepon());
            st.setInt(6,buku.getDurasi_sewa());
            st.setInt(7,buku.getTotal_biaya());
            
            st.executeUpdate();
            st.close();
        }catch(SQLException ex){
            System.out.println("INPUT GAGAL" + ex.getLocalizedMessage());
                
        }
    }

    @Override
    public void update(databuku buku) {
                try{
        String query = "UPDATE sewa_buku SET nama_penyewa=? ,judul_buku=? ,jenis_buku=? ,nomor_telepon=? ,durasi_sewa=? ,Total_biaya=? WHERE id=?;";
            databuku dm = new databuku();
            PreparedStatement st  ;
            st = connection.connenct().prepareStatement(query);
            st.setInt(1,buku.getId());
            st.setString(2,buku.getNama_penyewa());
            st.setString(3,buku.getJudul_buku());
            st.setString(4,buku.getJenis_buku());
            st.setString(5,buku.getNomor_telepon());
            st.setInt(6,buku.getDurasi_sewa());
            st.setInt(7,buku.getTotal_biaya());
            
            st.executeUpdate();
            st.close();
        }catch(SQLException ex){
            System.out.println("EDIT GAGAL" + ex.getLocalizedMessage());
                
        }
    }

    @Override
    public void delete(int id) {
        try{
            String query ="DELETE FROM sewa_buku WHERE id=?;";
            PreparedStatement st;
            st = connection.connenct().prepareStatement(query);
            st.setInt(1,id);
            st.executeUpdate();
            st.close();
        }catch(SQLException ex){
            System.out.println("DELETE gagal" + ex.getLocalizedMessage());
        }
    }

    @Override
    public List<databuku> getALL() {
        List<databuku>listbuku=null;
        try{
            listbuku = new ArrayList<>();
            Statement st = connection.connenct().createStatement();
            String query = "SELECT * FROM sewa_buku;";
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                databuku bk = new databuku();
                bk.setId(rs.getInt("id"));
                bk.setNama_penyewa(rs.getString("nama_penyewa"));
                bk.setJudul_buku(rs.getString("judul_buku"));
                bk.setJenis_buku(rs.getString("jenis_buku"));
                bk.setNomor_telepon(rs.getString("nomor_telepon"));
                bk.setDurasi_sewa(rs.getInt("durasi_sewa"));
                bk.setTotal_biaya(rs.getInt("total_biaya"));
                listbuku.add(bk);
            }st.close();
        }catch(SQLException e){
            System.out.println("Error"+e.getLocalizedMessage());
           
        }
    return listbuku;}
    
    
    
}
